from datetime import datetime

from app.analysis.issue_discovery import discover_issues
from app.analysis.reconciliation import reconcile_issue
from app.analysis.requirement_evaluator import evaluate_requirements
from app.analysis.rule_activation import activate_rules
from app.domain_contracts.schemas import (
    AssessmentStatus,
    EvidenceAssertion,
    EvidenceStatus,
    Obligation,
    Provenance,
)
from app.legal_knowledge.default_rules import extra_work_cost_communication_rule
from app.repositories.memory import store


def _p() -> Provenance:
    return Provenance(
        tenant_id="T1", matter_id="M1", analysis_run_id="R1", pipeline_version="test"
    )


def _assertion(assertion_type: str, statement: str, value=None, document: str = "D1") -> EvidenceAssertion:
    return EvidenceAssertion(
        tenant_id="T1",
        matter_id="M1",
        source_document_id=document,
        assertion_type=assertion_type,
        statement=statement,
        value=value,
        asserted_at=datetime(2025, 1, 3),
        provenance=_p(),
    )


def _obligation() -> Obligation:
    return Obligation(
        tenant_id="T1",
        matter_id="M1",
        clause_id="C1",
        obligation_type="change_order_approval",
        source_span_id="S1",
        provenance=_p(),
    )


def test_extra_work_rule_creates_separate_issues_by_extra_work_scope() -> None:
    store.issues.clear()
    store.rule_activations.clear()
    principle, rule = extra_work_cost_communication_rule()
    assertions = [
        _assertion("extra_work_detected", "Additional work at east slope", {"extra_work_id": "EW-1"}),
        _assertion("extra_work_detected", "Additional work at west slope", {"extra_work_id": "EW-2"}, "D2"),
    ]
    activations = activate_rules(rules=[rule], assertions=assertions)
    issues = discover_issues(
        tenant_id="T1", matter_id="M1", obligations=[_obligation()],
        assertions=assertions, rules=[rule], activations=activations,
    )

    assert len(issues) == 2
    assert {issue.extra_work_id for issue in issues} == {"EW-1", "EW-2"}
    assert all(rule.id in issue.rule_ids for issue in issues)


def test_proceed_is_not_cost_approval_and_negative_approval_is_contrary() -> None:
    _principle, rule = extra_work_cost_communication_rule()
    proceed = _assertion("instruction_to_proceed", "Please proceed with the extra work.")
    negative = _assertion("price_approval", "The owner never approved additional cost.", document="D2")
    checks = evaluate_requirements(
        rule=rule, assertions=[proceed, negative], search_attempts=[],
        tenant_id="T1", matter_id="M1", analysis_run_id="R1",
    )
    approval = next(check for check in checks if check.requirement_id == "owner_approved_additional_cost")

    assert approval.result == AssessmentStatus.disputed
    assert negative.id in approval.contrary_evidence_ids
    assert proceed.id not in approval.supporting_evidence_ids


def test_working_day_notice_deadline_does_not_use_calendar_days() -> None:
    obligation = Obligation(
        tenant_id="T1", matter_id="M1", clause_id="C1",
        obligation_type="notice_of_extra_compensation", trigger_event="delay",
        deadline_value=2, deadline_unit="working_days", source_span_id="S1", provenance=_p(),
    )
    assertion = _assertion(
        "written_notice", "Written notice was sent.",
        {"event_at": "2025-01-03", "notice_at": "2025-01-07"},
    )
    issue = discover_issues(
        tenant_id="T1", matter_id="M1", obligations=[obligation], assertions=[assertion]
    )[0]
    assessment = reconcile_issue(
        issue=issue, obligations=[obligation], assertions=[assertion], analysis_run_id="R1"
    )

    assert assessment.status == AssessmentStatus.satisfied
    assert assessment.evidence_status == EvidenceStatus.reconstructable
